package com.test.OzoneSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OzoneSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OzoneSpringBootApplication.class, args);
	}

}
